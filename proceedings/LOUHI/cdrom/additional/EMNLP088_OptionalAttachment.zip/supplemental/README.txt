README

female.txt is the female name gazetteer, male.txt is the male one, and hypocorisms.txt is the hypocorism gazetteer.

stop-list.txt contains the noun names that are excluded as being minor characters in Stage 8 of the the proposed method.

character-verb-predicates.tsv is the list of verbs used in Stage 8.  The first column is the verb and the second columns the name of the Stanford Dependency relation relating the noun to the verb in order for the predicate to be active.

moonstone, pride-and-prejudice, sherlock-holmes, and Sparknotes comprise
of the extracted and gold characters, respectively. Extracted characters for each story are listed in their own file, one character per line along with all the co-referents. The gold characters for each story are also listed in their own file with coreferents listed on each line and linked to characters by character identifiers.  We note that the Sparknotes only contains those characters listed on the website with a few additional naming variations produced by the methods in order to properly calculate Recall. 