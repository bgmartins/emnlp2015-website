== Overview ==
    The data includes both the students' responses and the gold-standard summaries created by 
    the teaching assistant. 
    Since the proposed method in the paper is unsupervised, no training set is needed.
    The results in the paper are reported when the lectures 1st, 9th, 10th, 12th are selected 
    as the development set, and the remaining lectures as the test sets.
   
== Format ==
    * There are 12 sheets in the excel, each corresponding to one lecture.
    * The column "Point of Interest" corresponds to the prompt:
        - Describe what you found most interesting in today's class.
    * The column "Muddiest Point" corresponds to the prompt:
        - Describe what was confusing or needed more detail.
    * The column "Learning Point" corresponds to the prompt:
        - Describe what you learned about how you learn.
    * The column "ID" are the anonymous students' ID 
    * The row "TA' Summary" corresponds the gold-standard summary for each prompt and each lecture
    * The results rows are the students' responses
    
    P.S. A cell with "[blank], N/A, blank, ?" means there is no student response or it is unintelligible