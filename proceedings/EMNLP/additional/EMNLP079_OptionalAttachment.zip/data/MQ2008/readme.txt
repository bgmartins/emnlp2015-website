Fold	Training.txt	Validation.txt Test.txt	
Fold1	S1, S2, S3	S4		S5	
Fold2	S2, S3, S4	S5		S1	
Fold3	S3, S4, S5	S1		S2	
Fold4	S4, S5, S1	S2		S3	
Fold5	S5, S1, S2	S3		S4	
